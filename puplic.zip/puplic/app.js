/* Global Variables */
const app = document.querySelector('#app');
const baseURL = '/api/weather?';
const key = '';//
let weather = {};
let fahrenheit = false;
let temperature = { temp: 0, sin: "°F" }
let stormAnimation ={t1:null,t2:null,t3:null}


// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth() + '.' + d.getDate() + '.' + d.getFullYear();


const temperatureConvertor = (temp) => {
    if (fahrenheit) {
        return temperature = { temp: Math.floor((temp - 273.15) * 9 / 5 + 32), sin: '°F' }
    }
    return temperature = { temp: Math.floor(temp - 273.15), sin: '°C' }
}
const performAction = (e) => {
    const audio = document.getElementById("stormAudio");
    clearInterval(stormAnimation.t1)
    clearInterval(stormAnimation.t2)
    clearInterval(stormAnimation.t3)
    app.classList.remove("storm");
    audio.pause();
    const zipCode = document.getElementById('zip').value;
    const feelings = document.getElementById('feelings').value;
    if (feelings.toUpperCase() !== "STORM") {
        getTemperature(zipCode)
            .then((data) => {
                // Add data to POST request
                postData('/addEntry', { temperature: data.main.temp, date: newDate, feeling: feelings })
                    // Function which updates UI
                    .then((data) => {
                        changAppMood();
                        updateUI()
                    })
            })
    } else {
        document.body.style.backgroundImage = `url('./images/Thunderstorm.jpg')`
        stormAnimation = {
            t1: setInterval(function () {
                app.classList.toggle("storm");
            }, 275),
            t2: setInterval(function () {
                app.classList.toggle("storm");
            }, 800)
            ,
            t3: setInterval(function () {
                app.classList.toggle("storm");
            }, 1200)
        }
        audio.play();
    }
}

// Async GET

// Async GET
const getTemperature = async (code) => {
    // const getTemperatureDemo = async (url)=>{
    const response = await fetch(baseURL + "zip=" + code + ',us' + key)
    try {
        weather = await response.json();
        console.log(weather);
        return weather;
    }
    catch (error) {
        console.error('error', error);
    }
}
const getTemperatureByLocation = async (lat, lon) => {
    // const getTemperatureDemo = async (url)=>{
    const response = await fetch(baseURL + `lat=${lat}&lon=${lon}` + key)
    try {
        weather = await response.json();
        console.log("location : ", weather);
        return weather;
    }
    catch (error) {
        console.error('error', error);
    }
}
// Async POST
const postData = async (url = '', data = {}) => {
    const postRequest = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    });
    try {
        const newData = await postRequest.json();
        return newData;
    }
    catch (error) {
        console.error('Error', error);
    }
}

// Update user interface
const updateUI = async () => {
    const request = await fetch('/entry');
    try {
        const allData = await request.json();
        document.getElementById('date').innerHTML = allData.date;
        document.getElementById('temp').innerHTML = temperatureConvertor(allData.temperature).temp;
        document.getElementById('temp').dataset.content = temperatureConvertor(allData.temperature).sin
        document.getElementById('content').innerHTML = allData.feeling;
        window.scrollTo({
            top: document.getElementById('entryHolder').offsetTop,
            behavior: 'smooth'
        });
    }
    catch (error) {
        console.log('error', error);
    }
}
document.getElementById('generate').addEventListener('click', performAction);
const changAppMood = () => {
    const weatherIcon = app.querySelector('.forcast-icon img')
    app.querySelector('.city-name h3').textContent = weather.name
    app.querySelector('.weather-temp h2').innerHTML = `<span>${weather.weather[0].main}</span>${temperatureConvertor(weather.main.temp).temp}`
    app.querySelector('.weather-temp h2').dataset.content = temperatureConvertor(weather.main.temp).sin

    weatherIcon.src = `http://openweathermap.org/img/wn/${weather.weather[0].icon}@2x.png`
    document.body.style.backgroundImage = `url('./images/${weather.weather[0].main}.jpg')`


}
/**
 * get a Geo of user by mobile loccation
 * https://developer.mozilla.org/en-US/docs/Web/API/Geolocation_API
 */
const geoFindMe = () => {



    function success(position) {
        const latitude = position.coords.latitude;
        const longitude = position.coords.longitude;
        /**
         * get a weather by user loccation
         */
        getTemperatureByLocation(latitude, longitude).then(() => {
            changAppMood();
        })

    }

    function error() {
        console.log('Unable to retrieve your location');
    }

    if (!navigator.geolocation) {
        console.log('Geolocation is not supported by your browser');
    } else {
        console.log('Locating…');
        navigator.geolocation.getCurrentPosition(success, error);
    }

}
geoFindMe();
